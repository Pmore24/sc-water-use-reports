Downloaded according to Courtney Kemmer's instructions in the email thread.
150,000 row maximum.

CA Pellett 
Jan 16, 2024

